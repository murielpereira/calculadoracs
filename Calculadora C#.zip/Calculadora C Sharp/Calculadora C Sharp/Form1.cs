﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_C_Sharp
{
    public partial class Form1 : Form
    {
        decimal valor1 = 0, valor2 = 0;
        string operacao = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            txtresultado.Text += "0";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            txtresultado.Text += "1";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            txtresultado.Text += "2";
        }

        private void button13_Click(object sender, EventArgs e)
        {
            txtresultado.Text += "3";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            txtresultado.Text += "4";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            txtresultado.Text += "5";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            txtresultado.Text += "6";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtresultado.Text += "7";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtresultado.Text += "8";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtresultado.Text += "9";
        }

        private void button18_Click(object sender, EventArgs e)
        {
            txtresultado.Text += ".";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            valor2 = decimal.Parse(txtresultado.Text, CultureInfo.InvariantCulture);

            if (operacao == "SOMA")
            {
                txtresultado.Text = Convert.ToString(valor1 + valor2);
            }
            else if (operacao == "SUB")
            {
                txtresultado.Text = Convert.ToString(valor1 - valor2);
            }
            else if (operacao == "MULT")
            {
                txtresultado.Text = Convert.ToString(valor1 * valor2);
            }
            else
            {
                txtresultado.Text = Convert.ToString(valor1 / valor2);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (txtresultado.Text != "")
            {
                valor1 = decimal.Parse(txtresultado.Text, CultureInfo.InvariantCulture);
                txtresultado.Text = "";
                operacao = "SUB";
                labaloperacao.Text = "-";
            }
            else
            {
                MessageBox.Show("Informe um valor para efetuar a operacao.");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (txtresultado.Text != "")
            {
                valor1 = decimal.Parse(txtresultado.Text, CultureInfo.InvariantCulture);

                txtresultado.Text = "";
                operacao = "MULT";
                labaloperacao.Text = "x";
            }
            else
            {
                MessageBox.Show("Informe um valor para efetuar a operacao.");
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (txtresultado.Text != "")
            {
                valor1 = decimal.Parse(txtresultado.Text, CultureInfo.InvariantCulture);

                txtresultado.Text = "";
                operacao = "DIV";
                labaloperacao.Text = "/";
            }
            else
            {
                MessageBox.Show("Informe um valor para efetuar a operacao.");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtresultado.Text = "";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtresultado.Text = "";
            valor1 = 0;
            valor2 = 0;
            labaloperacao.Text = "";
        }

        private void labaloperacao_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (txtresultado.Text != "")
            {
                valor1 = decimal.Parse(txtresultado.Text, CultureInfo.InvariantCulture);
                txtresultado.Text = "";
                operacao = "SOMA";
                labaloperacao.Text = "+";
            }
            else
            {
                MessageBox.Show("Informe um valor para efetuar a operacao.");
            }
        }
    }
}
